package com.example.lttbdd_t2_b2.ui.theme

import androidx.compose.ui.graphics.Color

// Bạn có thể khai báo các màu tùy chỉnh ở đây
val Purple40 = Color(0xFF6200EE)
val Purple80 = Color(0xFFBB86FC)
val Teal200 = Color(0xFF03DAC6)
